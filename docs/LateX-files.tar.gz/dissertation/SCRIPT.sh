#!/bin/bash
#this is a script to create the pdf file

pdflatex thesis1.tex
#now open it with your favourite pdf editor
