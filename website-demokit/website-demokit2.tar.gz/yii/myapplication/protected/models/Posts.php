<?php

/**
 * This is the model class for table "posts".
 *
 * The followings are the available columns in table 'posts':
 * @property integer $idposts
 * @property string $email
 * @property string $url
 * @property string $comment
 * @property double $whRatio
 * @property double $surfaceRatio
 * @property double $perimeterRatio
 * @property double $deviationR
 * @property double $deviationG
 * @property double $deviationB
 * @property double $meanR
 * @property double $meanG
 * @property double $meanB
 * @property double $maxR
 * @property double $maxG
 * @property double $maxB
 * @property double $gapRatio1
 * @property double $gapRatio2
 * @property double $gapRatio3
 * @property double $gapRatio4
 */
class Posts extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Posts the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'posts';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('email', 'required'),
			array('whRatio, surfaceRatio, perimeterRatio, deviationR, deviationG, deviationB, meanR, meanG, meanB, maxR, maxG, maxB, gapRatio1, gapRatio2, gapRatio3, gapRatio4', 'numerical'),
			array('email', 'length', 'max'=>45),
			array('url', 'length', 'max'=>200),
			array('comment', 'length', 'max'=>250),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('idposts, email, url, comment, whRatio, surfaceRatio, perimeterRatio, deviationR, deviationG, deviationB, meanR, meanG, meanB, maxR, maxG, maxB, gapRatio1, gapRatio2, gapRatio3, gapRatio4', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'email0' => array(self::BELONGS_TO, 'Users', 'email'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'idposts' => 'Idposts',
			'email' => 'Email',
			'url' => 'Url',
			'comment' => 'Comment',
			'whRatio' => 'Wh Ratio',
			'surfaceRatio' => 'Surface Ratio',
			'perimeterRatio' => 'Perimeter Ratio',
			'deviationR' => 'Deviation R',
			'deviationG' => 'Deviation G',
			'deviationB' => 'Deviation B',
			'meanR' => 'Mean R',
			'meanG' => 'Mean G',
			'meanB' => 'Mean B',
			'maxR' => 'Max R',
			'maxG' => 'Max G',
			'maxB' => 'Max B',
			'gapRatio1' => 'Gap Ratio1',
			'gapRatio2' => 'Gap Ratio2',
			'gapRatio3' => 'Gap Ratio3',
			'gapRatio4' => 'Gap Ratio4',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('idposts',$this->idposts);

		$criteria->compare('email',$this->email,true);

		$criteria->compare('url',$this->url,true);

		$criteria->compare('comment',$this->comment,true);

		$criteria->compare('whRatio',$this->whRatio);

		$criteria->compare('surfaceRatio',$this->surfaceRatio);

		$criteria->compare('perimeterRatio',$this->perimeterRatio);

		$criteria->compare('deviationR',$this->deviationR);

		$criteria->compare('deviationG',$this->deviationG);

		$criteria->compare('deviationB',$this->deviationB);

		$criteria->compare('meanR',$this->meanR);

		$criteria->compare('meanG',$this->meanG);

		$criteria->compare('meanB',$this->meanB);

		$criteria->compare('maxR',$this->maxR);

		$criteria->compare('maxG',$this->maxG);

		$criteria->compare('maxB',$this->maxB);

		$criteria->compare('gapRatio1',$this->gapRatio1);

		$criteria->compare('gapRatio2',$this->gapRatio2);

		$criteria->compare('gapRatio3',$this->gapRatio3);

		$criteria->compare('gapRatio4',$this->gapRatio4);

		return new CActiveDataProvider('Posts', array(
			'criteria'=>$criteria,
		));
	}
}