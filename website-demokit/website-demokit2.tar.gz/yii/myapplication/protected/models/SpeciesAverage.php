<?php

/**
 * This is the model class for table "speciesAverage".
 *
 * The followings are the available columns in table 'speciesAverage':
 * @property integer $idspecies
 * @property string $species
 * @property string $genus
 * @property double $whRatio
 * @property double $surfaceRatio
 * @property double $perimeterRatio
 * @property double $deviationR
 * @property double $deviationG
 * @property double $deviationB
 * @property double $meanR
 * @property double $meanG
 * @property double $meanB
 * @property double $maxR
 * @property double $maxG
 * @property double $maxB
 * @property double $gapRatio1
 * @property double $gapRatio2
 * @property double $gapRatio3
 * @property string $gapRatio4
 */
class SpeciesAverage extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return SpeciesAverage the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'speciesAverage';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('whRatio, surfaceRatio, perimeterRatio, deviationR, deviationG, deviationB, meanR, meanG, meanB, maxR, maxG, maxB, gapRatio1, gapRatio2, gapRatio3', 'numerical'),
			array('species, genus', 'length', 'max'=>45),
			array('gapRatio4', 'length', 'max'=>5),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('idspecies, species, genus, whRatio, surfaceRatio, perimeterRatio, deviationR, deviationG, deviationB, meanR, meanG, meanB, maxR, maxG, maxB, gapRatio1, gapRatio2, gapRatio3, gapRatio4', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'idspecies' => 'Idspecies',
			'species' => 'Species',
			'genus' => 'Genus',
			'whRatio' => 'Wh Ratio',
			'surfaceRatio' => 'Surface Ratio',
			'perimeterRatio' => 'Perimeter Ratio',
			'deviationR' => 'Deviation R',
			'deviationG' => 'Deviation G',
			'deviationB' => 'Deviation B',
			'meanR' => 'Mean R',
			'meanG' => 'Mean G',
			'meanB' => 'Mean B',
			'maxR' => 'Max R',
			'maxG' => 'Max G',
			'maxB' => 'Max B',
			'gapRatio1' => 'Gap Ratio1',
			'gapRatio2' => 'Gap Ratio2',
			'gapRatio3' => 'Gap Ratio3',
			'gapRatio4' => 'Gap Ratio4',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('idspecies',$this->idspecies);

		$criteria->compare('species',$this->species,true);

		$criteria->compare('genus',$this->genus,true);

		$criteria->compare('whRatio',$this->whRatio);

		$criteria->compare('surfaceRatio',$this->surfaceRatio);

		$criteria->compare('perimeterRatio',$this->perimeterRatio);

		$criteria->compare('deviationR',$this->deviationR);

		$criteria->compare('deviationG',$this->deviationG);

		$criteria->compare('deviationB',$this->deviationB);

		$criteria->compare('meanR',$this->meanR);

		$criteria->compare('meanG',$this->meanG);

		$criteria->compare('meanB',$this->meanB);

		$criteria->compare('maxR',$this->maxR);

		$criteria->compare('maxG',$this->maxG);

		$criteria->compare('maxB',$this->maxB);

		$criteria->compare('gapRatio1',$this->gapRatio1);

		$criteria->compare('gapRatio2',$this->gapRatio2);

		$criteria->compare('gapRatio3',$this->gapRatio3);

		$criteria->compare('gapRatio4',$this->gapRatio4,true);

		return new CActiveDataProvider('SpeciesAverage', array(
			'criteria'=>$criteria,
		));
	}
}