#!/bin/bash
echo $* | sed 's/.*\.//'
